<?php

return [
    'name' => 'Course',
];
