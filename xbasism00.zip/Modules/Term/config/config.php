<?php

return [
    'name' => 'Term',
];
